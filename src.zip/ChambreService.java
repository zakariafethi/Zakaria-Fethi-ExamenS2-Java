public interface ChambreService {
    void createChambre(Chambre chambre);
    void supprimerChambre(Chambre chambre);
    Chambre trouverChambre(int numeroChambre);
}
